﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim varName As Date = CDate(TextBox1.Text)

        Select Case TextBox1.Text
            Case "1 / 3 / 2000"
                TextBox2.Text = "Monday"
            Case "2 / 4 / 2003"
                TextBox2.Text = "Tuesday"
            Case "3 / 8 / 2006"
                TextBox2.Text = "Wednesday"
            Case "4 / 9 / 2009"
                TextBox2.Text = "Thursday"
            Case "5 / 11 / 2012"
                TextBox2.Text = "Friday"
            Case "6 / 11 / 2015"
                TextBox2.Text = "Saturday"
            Case "7 / 15 / 2018"
                TextBox2.Text = "Sunday"
            Case "8 / 16 / 2021"
                TextBox2.Text = "Monday"
            Case "9 / 21 / 2021"
                TextBox2.Text = "Tuesday"
            Case "10 / 19 / 2022"
                TextBox2.Text = "Wednesday"
            Case "11 / 24 / 2022"
                TextBox2.Text = "Thursday"
            Case "12 / 30 / 2022"
                TextBox2.Text = "Friday"


        End Select
        PictureBox1.Visible = False
        PictureBox2.Visible = False
        Label2.Visible = False

        If TextBox2.Text = "Sunday" Then
            PictureBox1.Visible = True
            Label2.Visible = True

        End If

        If TextBox2.Text = "Monday" Then
            PictureBox2.Visible = True
            Label3.Visible = True

        End If

        If TextBox2.Text = "Tuesday" Then
            PictureBox2.Visible = True
            Label3.Visible = True

        End If

        If TextBox2.Text = "Wednesday" Then
            PictureBox2.Visible = True
            Label3.Visible = True

        End If

        If TextBox2.Text = "Thursday" Then
            PictureBox2.Visible = True
            Label3.Visible = True

        End If

        If TextBox2.Text = "Friday" Then
            PictureBox2.Visible = True
            Label3.Visible = True

        End If


        If TextBox2.Text = "Saturday" Then
            PictureBox1.Visible = True
            Label2.Visible = True

        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        PictureBox1.Visible = False
        PictureBox2.Visible = False
        Label2.Visible = False
        Label3.Visible = False
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub
End Class
